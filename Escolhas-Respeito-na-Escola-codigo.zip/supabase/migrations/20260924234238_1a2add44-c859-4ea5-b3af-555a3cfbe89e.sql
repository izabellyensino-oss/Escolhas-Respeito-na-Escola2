CREATE TABLE public.game_players (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  player_key text NOT NULL UNIQUE CHECK (char_length(player_key) BETWEEN 20 AND 100),
  best_score integer NOT NULL DEFAULT 0 CHECK (best_score BETWEEN 0 AND 3000),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE ON public.game_players TO anon, authenticated;
GRANT ALL ON public.game_players TO service_role;

ALTER TABLE public.game_players ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view player count"
ON public.game_players
FOR SELECT
TO anon, authenticated
USING (true);

CREATE POLICY "Anyone can register an anonymous player"
ON public.game_players
FOR INSERT
TO anon, authenticated
WITH CHECK (player_key LIKE 'player_%');

CREATE POLICY "Anyone can update an anonymous player score"
ON public.game_players
FOR UPDATE
TO anon, authenticated
USING (player_key LIKE 'player_%')
WITH CHECK (player_key LIKE 'player_%');

CREATE OR REPLACE FUNCTION public.update_game_players_updated_at()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE TRIGGER set_game_players_updated_at
BEFORE UPDATE ON public.game_players
FOR EACH ROW
EXECUTE FUNCTION public.update_game_players_updated_at();