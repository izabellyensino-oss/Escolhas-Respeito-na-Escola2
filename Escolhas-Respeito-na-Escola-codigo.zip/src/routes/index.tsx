import { createFileRoute } from "@tanstack/react-router";
import { Game } from "../game/Game";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Escolhas: Respeito na Escola" },
      {
        name: "description",
        content: "Um jogo educativo sobre respeito, empatia e igualdade de gênero na escola.",
      },
      { property: "og:title", content: "Escolhas: Respeito na Escola" },
      {
        property: "og:description",
        content: "Viva situações escolares e faça escolhas que promovem respeito e igualdade.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return <Game />;
}
