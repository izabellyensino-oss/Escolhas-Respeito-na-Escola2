import { supabase } from "@/integrations/supabase/client";

type GameState = {
  bestScore?: number;
  statsDatabase?: Record<string, Record<string, number>>;
};

const tweaksValues: Record<string, string | number> = {
  gameTitle: "Escolhas: Respeito na Escola",
  initialRespect: 50,
  initialEmpathy: 50,
  initialAwareness: 40,
  soundVolume: 0.5,
};

let currentState: GameState = {};

function getPlayerKey() {
  const storageKey = "respeito-escola-player-key";
  const savedKey = window.localStorage.getItem(storageKey);
  if (savedKey) return savedKey;

  const newKey = `player_${crypto.randomUUID()}`;
  window.localStorage.setItem(storageKey, newKey);
  return newKey;
}

export const gameSdk = {
  gameState: {
    async load() {
      return currentState;
    },
    async save(nextState: GameState) {
      currentState = nextState;
    },
  },
  leaderboard: {
    async recordPlayer(score: number) {
      const playerKey = getPlayerKey();
      const { error: saveError } = await supabase
        .from("game_players")
        .upsert({ player_key: playerKey, best_score: score }, { onConflict: "player_key" });

      if (saveError) throw saveError;

      const { count, error: countError } = await supabase
        .from("game_players")
        .select("id", { count: "exact", head: true });

      if (countError) throw countError;
      return count ?? 0;
    },
    async submit(score: number) {
      await this.recordPlayer(score);
      return { accepted: true };
    },
  },
  device: {
    haptics: {
      isSupported() {
        return typeof navigator !== "undefined" && "vibrate" in navigator;
      },
      async vibrate(duration: number) {
        navigator.vibrate?.(duration);
      },
    },
  },
  audio: {
    async getContext() {
      return {
        async unlock() {},
      };
    },
  },
};

export const gameTweaks = {
  get(key: string) {
    return tweaksValues[key];
  },
};

export const gameAssets = {
  get(key: string) {
    const paths: Record<string, string> = {
      AMBIENT_MUSIC: "/generated-assets/6a453db219f28ce904b9f1a8.mp3",
      CHARACTER_ATLAS: "/generated-assets/character_atlas-transparent.webp",
      CHALKBOARD_BG: "/generated-assets/chalkboard_bg-transparent.webp",
      SCHOOL_BG: "/generated-assets/school_bg.webp",
      SALA_BG: "/generated-assets/sala_bg.webp",
      QUADRA_BG: "/generated-assets/quadra_bg.webp",
    };
    return paths[key];
  },
};
