import { useEffect, useRef } from "react";

import { createGame } from "./game.js";
import { gameAssets, gameSdk, gameTweaks } from "./game-runtime";
import "./game.css";

export function Game() {
  const mountRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    const game = createGame({
      mount,
      sdk: gameSdk,
      ready: true,
      tweaks: gameTweaks,
      assets: gameAssets,
    });

    game.start();
    return () => game.destroy();
  }, []);

  return <div ref={mountRef} className="h-dvh w-full overflow-hidden" />;
}