export type GameController = {
  start(): void;
  destroy(): void;
};

export function createGame(options: {
  mount: HTMLElement;
  sdk: unknown;
  ready: unknown;
  tweaks: unknown;
  assets: unknown;
}): GameController;
