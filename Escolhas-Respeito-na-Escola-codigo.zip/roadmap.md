# Roadmap

- [x] Corrigir definitivamente as cores verde, laranja e vermelha das 21 barras
- [x] Adicionar ranking persistente com quantidade de jogadores
- [x] Verificar a tela final e o ranking
